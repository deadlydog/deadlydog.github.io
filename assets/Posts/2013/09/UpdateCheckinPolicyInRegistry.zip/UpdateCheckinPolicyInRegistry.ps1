# This script copies the required registry value so that the checkin policies will work when doing a TFS checkin from the command line.

# Turn on Strict Mode to help catch syntax-related errors.
# 	This must come after a script's/function's param section.
# 	Forces a function to be the first non-comment code to appear in a PowerShell Module.
Set-StrictMode -Version Latest

$ScriptBlock = {
    # The name of the Custom Checkin Policy Entry in the Registry Key.
    $CustomCheckinPolicyEntryName = 'YourCustomCheckinPolicyEntryNameGoesHere'

    # Get the Registry Key Entry that holds the path to the Custom Checkin Policy Assembly.
    $CustomCheckinPolicyRegistryEntry = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\VisualStudio\11.0_Config\TeamFoundation\SourceControl\Checkin Policies' -Name $CustomCheckinPolicyEntryName
    $CustomCheckinPolicyEntryValue = $CustomCheckinPolicyRegistryEntry.($CustomCheckinPolicyEntryName)

    # Create a new Registry Key Entry for the iQ Checkin Policy Assembly so they will work from the command line (as well as from Visual Studio).
    if ([Environment]::Is64BitOperatingSystem)
    { $HKLMKey = 'HKLM:\SOFTWARE\Wow6432Node\Microsoft\VisualStudio\11.0\TeamFoundation\SourceControl\Checkin Policies' }
    else
    { $HKLMKey = 'HKLM:\SOFTWARE\Microsoft\VisualStudio\11.0\TeamFoundation\SourceControl\Checkin Policies' }
    Set-ItemProperty -Path $HKLMKey -Name $CustomCheckinPolicyEntryName -Value $CustomCheckinPolicyEntryValue
}

# Run the script block as admin so it has permissions to modify the registry.
Start-Process -FilePath PowerShell -Verb RunAs -ArgumentList "-Command $ScriptBlock"