# Get the directory that this script is in.
$thisScriptsDirectory = Split-Path $script:MyInvocation.MyCommand.Path

# Remove Rq application services for versions 4.11.33 to 4.11.43.
$majorMinorVersion = "4.11"
33..43 | foreach {
    $Release = "$majorMinorVersion.$_"
    Write-Host "Removing Rq '$Release' services..."
    & "$thisScriptsDirectory\Remove-RqServices.ps1" $Release
}