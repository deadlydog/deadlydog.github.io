# Get the directory that this script is in.
$THIS_SCRIPTS_DIRECTORY = Split-Path $script:MyInvocation.MyCommand.Path

# Include the required ApplicationServiceInformation type.
. (Join-Path $THIS_SCRIPTS_DIRECTORY ApplicationServiceUtilities.ps1)

#=================================
# Replace all of the functions below with your own.
# These are provided as examples.
#=================================

function Get-AllApplicationServiceInformation([string] $Release)
{
    [ApplicationServiceInformation[]] $appServiceInfo = @()

    $appServiceInfo += Get-RqApplicationServiceInformation -Release $Release
    $appServiceInfo += Get-PublicApiApplicationServiceInformation -Release $Release
    $appServiceInfo += Get-IntraApplicationServiceInformation -Release $Release

    return $appServiceInfo    
}

function Get-RqApplicationServiceInformation([string] $Release)
{
    return [ApplicationServiceInformation[]] @(
	    (New-Object ApplicationServiceInformation -Property @{Website = "Application Services"; ApplicationPath = "$Release/Core.Reporting.Services"; ApplicationPool = "RQ Services .NET4"}),
	    (New-Object ApplicationServiceInformation -Property @{Website = "Application Services"; ApplicationPath = "$Release/Core.Services"; ApplicationPool = "RQ Core Services .NET4"}),
	    (New-Object ApplicationServiceInformation -Property @{Website = "Application Services"; ApplicationPath = "$Release/DeskIntegration.Services"; ApplicationPool = "RQ Services .NET4"}),
	    (New-Object ApplicationServiceInformation -Property @{Website = "Application Services"; ApplicationPath = "$Release/Retail.Integration.Services"; ApplicationPool = "RQ Services .NET4"}),

        # Simulator Services that are only for Dev; we don't want to convert them to an application, but do want to remove their files that got copied to the web server.
        (New-Object ApplicationServiceInformation -Property @{Website = "Application Services"; ApplicationPath = "$Release/Simulator.Services"; ApplicationPool = "Simulator Services .NET4"; ConvertToApplication = $false}))
}

function Get-PublicApiApplicationServiceInformation([string] $Release)
{
    return [ApplicationServiceInformation[]] @(
        (New-Object ApplicationServiceInformation -Property @{Website = "API Services"; ApplicationPath = "$Release/PublicAPI.Host"; ApplicationPool = "API Services .NET4"}),
	    (New-Object ApplicationServiceInformation -Property @{Website = "API Services"; ApplicationPath = "$Release/PublicAPI.Documentation"; ApplicationPool = "API Services .NET4"}))
}

function Get-IntraApplicationServiceInformation([string] $Release)
{
    return [ApplicationServiceInformation[]] @(
        (New-Object ApplicationServiceInformation -Property @{Website = "Intra Services"; ApplicationPath = "$Release"; ApplicationPool = "Intra Services .NET4"}))
}