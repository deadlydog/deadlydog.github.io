# Turn on Strict Mode to help catch syntax-related errors.
# 	This must come after a script's/function's param section.
# 	Forces a function to be the first non-comment code to appear in a PowerShell Module.
Set-StrictMode -Version Latest

# Define the code block that will add the ApplicationServiceInformation class to the PowerShell session.
# NOTE: If this class is modified you will need to restart your PowerShell session to see the changes.
$AddApplicationServiceInformationTypeScriptBlock = {
    # Wrap in a try-catch in case we try to add this type twice.
    try {
    # Create a class to hold an IIS Application Service's Information.
    Add-Type -TypeDefinition "
        using System;
    
        public class ApplicationServiceInformation
        {
            // The name of the Website in IIS.
            public string Website { get; set;}
        
            // The path to the Application, relative to the Website root.
            public string ApplicationPath { get; set; }

            // The Application Pool that the application is running in.
            public string ApplicationPool { get; set; }

            // Whether this application should be published or not.
            public bool ConvertToApplication { get; set; }

            // Implicit Constructor.
            public ApplicationServiceInformation() { this.ConvertToApplication = true; }

            // Explicit constructor.
            public ApplicationServiceInformation(string website, string applicationPath, string applicationPool, bool convertToApplication = true)
            {
                this.Website = website;
                this.ApplicationPath = applicationPath;
                this.ApplicationPool = applicationPool;
                this.ConvertToApplication = convertToApplication;
            }
        }
    "
    } catch {}
}
# Add the ApplicationServiceInformation class to this PowerShell session.
& $AddApplicationServiceInformationTypeScriptBlock

<#
    .SYNOPSIS
    Converts the given files to application services on the given Server.

    .PARAMETER Server
    The Server Host Name to connect to and convert the applications on.

    .PARAMETER ApplicationServicesInfo
    The [ApplicationServiceInformation[]] containing the files to convert to application services.
#>
function ConvertTo-ApplicationServices
{
    [CmdletBinding()]
    param
    (
        [string] $Server,
        [ApplicationServiceInformation[]] $ApplicationServicesInfo
    )

    $block = {
	    param([PSCustomObject[]] $ApplicationServicesInfo)
        $VerbosePreference = $Using:VerbosePreference
	    Write-Verbose "Converting To Application Services..."

        # Import the WebAdministration module to make sure we have access to the required cmdlets and the IIS: drive.
        Import-Module WebAdministration 4> $null	# Don't write the verbose output.
	
	    # Create all of the Web Applications, making sure to first try and remove them in case they already exist (in order to avoid a PS error).
	    foreach ($appInfo in [PSCustomObject[]]$ApplicationServicesInfo)
        {
            $website = $appInfo.Website
            $applicationPath = $appInfo.ApplicationPath
            $applicationPool = $appInfo.ApplicationPool
		    $fullPath = Join-Path $website $applicationPath

            # If this application should not be converted, continue onto the next one in the list.
            if (!$appInfo.ConvertToApplication) { Write-Verbose "Skipping publish of '$fullPath'"; continue }
		
		    Write-Verbose "Checking if we need to remove '$fullPath' before converting it..."
		    if (Get-WebApplication -Site "$website" -Name "$applicationPath")
		    {
			    Write-Verbose "Removing '$fullPath'..."
			    Remove-WebApplication -Site "$website" -Name "$applicationPath"
		    }

            Write-Verbose "Converting '$fullPath' to an application with Application Pool '$applicationPool'..."
            ConvertTo-WebApplication "IIS:\Sites\$fullPath" -ApplicationPool "$applicationPool"
        }
    }

    # Connect to the host Server and run the commands directly o that computer.
    # Before we run our script block we first have to add the ApplicationServiceInformation class type into the PowerShell session.
    $session = New-PSSession -ComputerName $Server
    Invoke-Command -Session $session -ScriptBlock $AddApplicationServiceInformationTypeScriptBlock
    Invoke-Command -Session $session -ScriptBlock $block -ArgumentList (,$ApplicationServicesInfo)
    Remove-PSSession -Session $session
}

<#
    .SYNOPSIS
    Removes the given application services from the given Server.

    .PARAMETER Server
    The Server Host Name to connect to and remove the applications from.

    .PARAMETER ApplicationServicesInfo
    The [ApplicationServiceInformation[]] containing the applications to remove.
#>
function Remove-ApplicationServices
{
    [CmdletBinding()]
    param
    (
        [string] $Server,
        [ApplicationServiceInformation[]] $ApplicationServicesInfo
    )

    $block = {
	    param([ApplicationServiceInformation[]] $ApplicationServicesInfo)
        $VerbosePreference = $Using:VerbosePreference
	    Write-Verbose "Removing Application Services..."

        # Import the WebAdministration module to make sure we have access to the required cmdlets and the IIS: drive.
        Import-Module WebAdministration 4> $null	# Don't write the verbose output.

	    # Remove all of the Web Applications, making sure they exist first (in order to avoid a PS error).
	    foreach ($appInfo in [ApplicationServiceInformation[]]$ApplicationServicesInfo)
        {
            $website = $appInfo.Website
            $applicationPath = $appInfo.ApplicationPath
		    $fullPath = Join-Path $website $applicationPath
		
		    Write-Verbose "Checking if we need to remove '$fullPath'..."
		    if (Get-WebApplication -Site "$website" -Name "$applicationPath")
		    {
			    Write-Verbose "Removing '$fullPath'..."
			    Remove-WebApplication -Site "$website" -Name "$applicationPath"
		    }
        }
    }

    # Connect to the host Server and run the commands directly on that computer.
    # Before we run our script block we first have to add the ApplicationServiceInformation class type into the PowerShell session.
    $session = New-PSSession -ComputerName $Server
    Invoke-Command -Session $session -ScriptBlock $AddApplicationServiceInformationTypeScriptBlock
    Invoke-Command -Session $session -ScriptBlock $block -ArgumentList (,$ApplicationServicesInfo)
    Remove-PSSession -Session $session
}

<#
    .SYNOPSIS
    Removes the given application services from the given Server and deletes all associated files.

    .PARAMETER Server
    The Server Host Name to connect to and delete the applications from.

    .PARAMETER ApplicationServicesInfo
    The [ApplicationServiceInformation[]] containing the applications to delete.

    .PARAMETER OnlyDeleteIfNotConvertedToApplication
    If this switch is supplied and the application services are still running (i.e. have not been removed yet), the services will not be removed and the files will not be deleted.

    .PARAMETER DeleteEmptyParentDirectories
    If this switch is supplied, after the application services folder has been removed, it will recursively check parent folders and remove them if they are empty, until the Website root is reached.
#>
function Delete-ApplicationServices
{
    [CmdletBinding()]
    param
    (
        [string] $Server,
        [ApplicationServiceInformation[]] $ApplicationServicesInfo,
        [switch] $OnlyDeleteIfNotConvertedToApplication,
        [switch] $DeleteEmptyParentDirectories
    )
    
    $block = {
	    param([ApplicationServiceInformation[]] $ApplicationServicesInfo)
        $VerbosePreference = $Using:VerbosePreference
	    Write-Verbose "Deleting Application Services..."

        # Import the WebAdministration module to make sure we have access to the required cmdlets and the IIS: drive.
        Import-Module WebAdministration 4> $null	# Don't write the verbose output.

	    # Remove all of the Web Applications and delete their files from disk.
	    foreach ($appInfo in [ApplicationServiceInformation[]]$ApplicationServicesInfo)
        {
            $website = $appInfo.Website
            $applicationPath = $appInfo.ApplicationPath
		    $fullPath = Join-Path $website $applicationPath
            $iisSitesDirectory = "IIS:\Sites\"
		
		    Write-Verbose "Checking if we need to remove '$fullPath'..."
		    if (Get-WebApplication -Site "$website" -Name "$applicationPath")
		    {
                # If we should only delete the files they're not currently running as a Web Application, continue on to the next one in the list.
                if ($Using:OnlyDeleteIfNotConvertedToApplication) { Write-Verbose "'$fullPath' is still running as a Web Application, so its files will not be deleted."; continue }

			    Write-Verbose "Removing '$fullPath'..."
			    Remove-WebApplication -Site "$website" -Name "$applicationPath"
		    }
            
            Write-Verbose "Deleting the directory '$fullPath'..."
            Remove-Item -Path "$iisSitesDirectory$fullPath" -Recurse -Force

            # If we should delete empty parent directories of this application.
            if ($Using:DeleteEmptyParentDirectories)
            {
                Write-Verbose "Deleting empty parent directories..."
                $parent = Split-Path -Path $fullPath -Parent

                # Only delete the parent directory if it is not the Website directory, and it is empty.
                while (($parent -ne $website) -and (Test-Path -Path "$iisSitesDirectory$parent") -and ((Get-ChildItem -Path "$iisSitesDirectory$parent") -eq $null))
                {
                    $path = $parent
                    Write-Verbose "Deleting empty parent directory '$path'..."
                    Remove-Item -Path "$iisSitesDirectory$path" -Force
                    $parent = Split-Path -Path $path -Parent
                }
            }
        }
    }

    # Connect to the host Server and run the commands directly on that computer.
    # Before we run our script block we first have to add the ApplicationServiceInformation class type into the PowerShell session.
    $session = New-PSSession -ComputerName $Server
    Invoke-Command -Session $session -ScriptBlock $AddApplicationServiceInformationTypeScriptBlock
    Invoke-Command -Session $session -ScriptBlock $block -ArgumentList (,$ApplicationServicesInfo)
    Remove-PSSession -Session $session
}