param
(
	[parameter(Position=0,Mandatory=$true,HelpMessage="The 3 hex-value version number of the release (x.x.x).")]
	[ValidatePattern("^\d{1,5}\.\d{1,5}\.\d{1,5}$")]
	[string] $Release
)

# Get the directory that this script is in.
$THIS_SCRIPTS_DIRECTORY = Split-Path $script:MyInvocation.MyCommand.Path

# Include the functions used to perform the actual operations.
. (Join-Path $THIS_SCRIPTS_DIRECTORY ApplicationServiceLibrary.ps1)

Remove-ApplicationServices -Server "IQWEB3.iQmetrixHO.local" -ApplicationServicesInfo (Get-RqApplicationServiceInformation -Release $Release) -Verbose