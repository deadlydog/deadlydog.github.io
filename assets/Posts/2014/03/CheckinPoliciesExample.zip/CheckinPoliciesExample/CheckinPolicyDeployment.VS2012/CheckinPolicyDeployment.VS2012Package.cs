﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.ComponentModel.Design;
using Microsoft.Win32;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio.OLE.Interop;
using Microsoft.VisualStudio.Shell;

namespace iQmetrix.CheckinPolicyDeployment_VS2012
{
	[Guid(GuidList.guidCheckinPolicyDeployment_VS2012PkgString)]
	public sealed class CheckinPolicyDeployment_VS2012Package : CheckinPolicyDeploymentShared.CheckinPolicyDeploymentPackage
	{ }
}
