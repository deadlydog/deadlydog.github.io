﻿// Guids.cs
// MUST match guids.h
using System;

namespace iQmetrix.CheckinPolicyDeployment_VS2012
{
	static class GuidList
	{
		public const string guidCheckinPolicyDeployment_VS2012PkgString = "88CF0D10-2D42-127D-9D00-19E9B55E8385";
		public const string guidCheckinPolicyDeployment_VS2012CmdSetString = "E40E4600-2D42-127D-99A7-1190EEEB2E8B";

		public static readonly Guid guidCheckinPolicyDeployment_VS2012CmdSet = new Guid(guidCheckinPolicyDeployment_VS2012CmdSetString);
	};
}