﻿// Guids.cs
// MUST match guids.h
using System;

namespace iQmetrix.CheckinPolicyDeployment_VS2013
{
	static class GuidList
	{
		public const string guidCheckinPolicyDeployment_VS2013PkgString = "7EFC0E60-2D41-127D-9EE0-158F646F408E";
		public const string guidCheckinPolicyDeployment_VS2013CmdSetString = "07E0A730-2D43-127D-9C18-12AB1683E623";

		public static readonly Guid guidCheckinPolicyDeployment_VS2013CmdSet = new Guid(guidCheckinPolicyDeployment_VS2013CmdSetString);
	};
}