﻿using System;
using System.Linq;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Framework.Client;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace CheckinPolicies.Common
{
    /// <summary>
    /// The base class that all of the policies should inherit from.
    /// </summary>
    [Serializable]
    public abstract class CheckinPolicyBase : PolicyBase
    {
        /// <summary>
        /// The list of pending changes to be checked in.
        /// </summary>
        [NonSerialized]
        protected IPendingCheckin _pendingCheckin;

        /// <summary>
        /// Gets the Name of the policy, displayed in the policy list and Add Check-in Policy box when you add a new policy to a Team Project.
        /// </summary>
        public abstract string Name { get; }

        /// <summary>
        /// Gets the Short Description displayed in the policy list when you add a new policy to a Team Project.
        /// </summary>
        public abstract string ShortDescription { get; }

        /// <summary>
        /// Gets the full Description displayed when you select the policy in the Add Check-in Policy dialog box. 
        /// </summary>
        public abstract string LongDescription { get; }

        /// <summary>
        /// Gets the Name of the policy displayed in the policy list and Add Check-in Policy box when you add a new policy to a Team Project.
        /// </summary>
        public override string Type
        {
            get { return this.Name; }
        }

        /// <summary>
        /// Gets the description displayed in the policy list when you add a new policy to a Team Project.
        /// </summary>
        public override string Description
        {
            get { return this.ShortDescription; }
        }

        /// <summary>
        /// Gets the description displayed when you select the policy in the Add Check-in Policy dialog box. 
        /// </summary>
        public override string TypeDescription
        {
            get { return this.LongDescription; }
        }

        /// <summary>
        /// Gets the instructions to display to the user about how to install this policy.
        /// </summary>
        public override string InstallationInstructions
        {
            get { return "Please install/update your Checkin Policies package.\n\n"; }
        }

        /// <summary>
        /// This method is called by the policy framework when you create a new check-in policy or edit an existing check-in policy.
        /// You can use this to display a UI specific to this policy type allowing the user to change the parameters of the policy. 
        /// </summary>
        /// <param name="args">The arguments.</param>
        public override bool Edit(IPolicyEditArgs args)
        {
            // This must be true or else the policies can not be added to the Team Project for some reason.
            return true;
        }

        /// <summary>
        /// Initializes this policy for the specified pending check-in.
        /// </summary>
        /// <param name="pendingCheckin">The pending check-in.</param>
        public override void Initialize(IPendingCheckin pendingCheckin)
        {
            base.Initialize(pendingCheckin);

            _pendingCheckin = pendingCheckin;
            _pendingCheckin.PendingChanges.CheckedPendingChangesChanged += PendingChanges_CheckedPendingChangesChanged;
        }

        /// <summary>
        /// Re-evaluates the policy each time the list of files with pending changes is updated.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        void PendingChanges_CheckedPendingChangesChanged(object sender, EventArgs e)
        {
            if (!Disposed)
                OnPolicyStateChanged(Evaluate());
        }

        /// <summary>
        /// Dispose method unsubscribes to the event so we don't get into scenarios that can create null ref exceptions
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            _pendingCheckin.PendingChanges.CheckedPendingChangesChanged -= PendingChanges_CheckedPendingChangesChanged;
        }
    }
}