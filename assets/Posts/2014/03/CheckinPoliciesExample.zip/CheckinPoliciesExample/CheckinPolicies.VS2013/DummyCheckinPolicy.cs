﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.TeamFoundation.VersionControl.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using System.IO;
using System.Text.RegularExpressions;
using CheckinPolicies.Common;

namespace CheckinPolicies
{
	[Serializable]
	public class DummyCheckinPolicy : CheckinPolicyBase
	{
		/// <summary>
		/// Gets the Name of the policy, displayed in the policy list and Add Check-in Policy box when you add a new policy to a Team Project.
		/// </summary>
		public override string Name
		{
			get { return "Dummy Checkin Policy"; }
		}

		/// <summary>
		/// Gets the Short Description displayed in the policy list when you add a new policy to a Team Project.
		/// </summary>
		public override string ShortDescription
		{
			get { return "Dummy Checkin Policy"; }
		}

		/// <summary>
		/// Gets the full Description displayed when you select the policy in the Add Check-in Policy dialog box.
		/// </summary>
		public override string LongDescription
		{
			get { return "Dummy Checkin Policy"; }
		}

		/// <summary>
		/// Evaluates the pending changes for policy violations.
		/// </summary>
		public override PolicyFailure[] Evaluate()
		{
			var failures = new List<PolicyFailure>();
			string filePath = string.Empty;
			
			//// Loop through all of the pending changes being checked in
			//foreach (var pendingChange in _pendingCheckin.PendingChanges.CheckedPendingChanges)
			//{
			//    filePath = pendingChange.LocalItem;

			//    // Make sure that the item exists locally
			//    if (!File.Exists(filePath))
			//        continue;
			//}

			return failures.ToArray();
		}
	}
}