﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EnvDTE80;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.Win32;
using System.IO;

namespace CheckinPolicyDeploymentShared
{
	/// <summary>
	/// This is the class that implements the package exposed by this assembly.
	///
	/// The minimum requirement for a class to be considered a valid package for Visual Studio
	/// is to implement the IVsPackage interface and register itself with the shell.
	/// This package uses the helper classes defined inside the Managed Package Framework (MPF)
	/// to do it: it derives from the Package class that provides the implementation of the 
	/// IVsPackage interface and uses the registration attributes defined in the framework to 
	/// register itself and its components with the shell.
	/// </summary>
	// This attribute tells the PkgDef creation utility (CreatePkgDef.exe) that this class is
	// a package.
	[PackageRegistration(UseManagedResourcesOnly = true)]
	// This attribute is used to register the information needed to show this package
	// in the Help/About dialog of Visual Studio.
	[InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)]
	// Auto Load our assembly even when no solution is open (by using the Microsoft.VisualStudio.VSConstants.UICONTEXT_NoSolution guid).
	[ProvideAutoLoad("ADFC4E64-0397-11D1-9F4E-00A0C911004F")]
	public abstract class CheckinPolicyDeploymentPackage : Package
	{
		private EnvDTE.DTEEvents _dteEvents;

		/// <summary>
		/// Initialization of the package; this method is called right after the package is sited, so this is the place
		/// where you can put all the initialization code that rely on services provided by VisualStudio.
		/// </summary>
		protected override void Initialize()
		{
			base.Initialize();

			var dte = (DTE2)GetService(typeof(SDTE));
			_dteEvents = dte.Events.DTEEvents;
			_dteEvents.OnBeginShutdown += OnBeginShutdown;

			UpdateCheckinPoliciesInRegistry();
		}

		private void OnBeginShutdown()
		{
			_dteEvents.OnBeginShutdown -= OnBeginShutdown;
			_dteEvents = null;

			UpdateCheckinPoliciesInRegistry();
		}

		private void UpdateCheckinPoliciesInRegistry()
		{
			var dte = (DTE2)GetService(typeof(SDTE));
			string visualStudioVersionNumber = dte.Version;
			string customCheckinPolicyEntryName = "CheckinPolicies";

			// Create the paths to the registry keys that contains the values to inspect.
			string desiredRegistryKeyPath = string.Format("HKEY_CURRENT_USER\\Software\\Microsoft\\VisualStudio\\{0}_Config\\TeamFoundation\\SourceControl\\Checkin Policies", visualStudioVersionNumber);
			string currentRegistryKeyPath = string.Empty;
			if (Environment.Is64BitOperatingSystem)
				currentRegistryKeyPath = string.Format("HKEY_LOCAL_MACHINE\\SOFTWARE\\Wow6432Node\\Microsoft\\VisualStudio\\{0}\\TeamFoundation\\SourceControl\\Checkin Policies", visualStudioVersionNumber);
			else
				currentRegistryKeyPath = string.Format("HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\VisualStudio\\{0}\\TeamFoundation\\SourceControl\\Checkin Policies", visualStudioVersionNumber);

			// Get the value that the registry should have, and the value that it currently has.
			var desiredRegistryValue = Registry.GetValue(desiredRegistryKeyPath, customCheckinPolicyEntryName, null);
			var currentRegistryValue = Registry.GetValue(currentRegistryKeyPath, customCheckinPolicyEntryName, null);

			// If the registry value is already up to date, just exit without updating the registry.
			if (desiredRegistryValue == null || desiredRegistryValue.Equals(currentRegistryValue))
				return;

			// Get the path to the PowerShell script to run.
			string powerShellScriptFilePath = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetAssembly(typeof(CheckinPolicyDeploymentPackage)).Location),
				"FilesFromShared", "UpdateCheckinPolicyInRegistry.ps1");

			// Start a new process to execute the batch file script, which calls the PowerShell script to do the actual work.
			var process = new Process
			{
				StartInfo =
				{
					FileName = "PowerShell",
					Arguments = string.Format("-NoProfile -ExecutionPolicy Bypass -File \"{0}\" -VisualStudioVersion \"{1}\" -CustomCheckinPolicyEntryName \"{2}\"", powerShellScriptFilePath, visualStudioVersionNumber, customCheckinPolicyEntryName),

					// Hide the PowerShell window while we run the script.
					CreateNoWindow = true,
					UseShellExecute = false
				}
			};
			process.Start();
		}
	}
}
