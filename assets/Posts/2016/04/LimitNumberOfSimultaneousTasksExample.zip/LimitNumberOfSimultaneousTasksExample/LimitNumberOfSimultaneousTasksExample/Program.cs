﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using DansCSharpLibrary.Threading;

namespace LimitNumberOfSimultaneousTasksExample
{
	class Program
	{
		private const int ThreadSleepTimeInMilliseconds = 1000;

		static void Main(string[] args)
		{
			int numberOfTasksToRun = 50;
			int maxNumberOfTasksToRunInParallel = 3;

			// Note: Of these 2, the 2nd one called always seems to run faster, so it's not the one method (Action vs Task) is faster than the other.
			TimeAction(() => DoSomethingALotWithTasks(numberOfTasksToRun));
			TimeAction(() => DoSomethingALotWithActions(numberOfTasksToRun));

			TimeAction(() => DoSomethingALotWithTasksThrottled(numberOfTasksToRun, maxNumberOfTasksToRunInParallel));
			TimeAction(() => DoSomethingALotWithActionsThrottled(numberOfTasksToRun, maxNumberOfTasksToRunInParallel));

			Console.WriteLine("Press Enter to exit...");
			Console.ReadLine();
		}

		public static void DoSomethingALotWithTasks(int numberOfTasksToRun)
		{
			Console.WriteLine("Let the OS determine how many Tasks to execute concurrently.");
			var listOfTasks = new List<Task>();
			for (int i = 0; i < numberOfTasksToRun; i++)
			{
				var count = i;
				// Note that we start the Task here too.
				listOfTasks.Add(Task.Run(() => DoSomething(count)));
			}
			Task.WaitAll(listOfTasks.ToArray());
		}

		public static void DoSomethingALotWithActions(int numberOfTasksToRun)
		{
			Console.WriteLine("Let the OS determine how many Actions to execute concurrently.");
			var listOfActions = new List<Action>();
			for (int i = 0; i < numberOfTasksToRun; i++)
			{
				var count = i;
				// Note that we create the Action here, but do not start it.
				listOfActions.Add(() => DoSomething(count));
			}
			Parallel.Invoke(listOfActions.ToArray());
		}

		public static void DoSomethingALotWithTasksThrottled(int numberOfTasksToRun, int maxNumberOfTasksToRunInParallel)
		{
			Console.WriteLine(string.Format("Only allow a maximum of {0} Tasks to execute concurrently.", maxNumberOfTasksToRunInParallel));
			var listOfTasks = new List<Task>();
			for (int i = 0; i < numberOfTasksToRun; i++)
			{
				var count = i;
				// Note that we create the Task here, but do not start it.
			   listOfTasks.Add(new Task(() => DoSomething(count)));
			}
			Tasks.StartAndWaitAllThrottled(listOfTasks, maxNumberOfTasksToRunInParallel);
		}

		public static void DoSomethingALotWithActionsThrottled(int numberOfTasksToRun, int maxNumberOfTasksToRunInParallel)
		{
			Console.WriteLine(string.Format("Only allow a maximum of {0} Actions to execute concurrently.", maxNumberOfTasksToRunInParallel));
			var listOfActions = new List<Action>();
			for (int i = 0; i < numberOfTasksToRun; i++)
			{
				var count = i;
				// Note that we create the Action here, but do not start it.
				listOfActions.Add(() => DoSomething(count));
			}

			var options = new ParallelOptions {MaxDegreeOfParallelism = maxNumberOfTasksToRunInParallel};
			Parallel.Invoke(options, listOfActions.ToArray());
		}

		public static void DoSomething(int taskNumber)
		{
			Console.WriteLine(string.Format("[{0}] Task Number: {1}", DateTime.Now.ToString("hh:mm:ss.ffffff"), taskNumber));
			Thread.Sleep(TimeSpan.FromMilliseconds(ThreadSleepTimeInMilliseconds));
		}

		public static void TimeAction(Action action)
		{
			// Timer used to see how long it takes to perform the operations.
			var timer = System.Diagnostics.Stopwatch.StartNew();

			// Perform Operation
			action.Invoke();

			// Get how long it took to do all of the operations, and create a nice user-friendly string to show it.
			var elapsedTime = timer.Elapsed;
			string elapsedTimeString = string.Empty;
			if (elapsedTime.Days > 0)
				elapsedTimeString += string.Format("{0} day(s), ", elapsedTime.Days.ToString());
			if (elapsedTime.Hours > 0)
				elapsedTimeString += string.Format("{0} hour(s), ", elapsedTime.Hours.ToString());
			if (elapsedTime.Minutes > 0)
				elapsedTimeString += string.Format("{0} minute(s) and ", elapsedTime.Minutes.ToString());
			if (elapsedTime.TotalSeconds > 10)
				elapsedTimeString += string.Format("{0} seconds", elapsedTime.Seconds.ToString());
			else if (elapsedTime.TotalSeconds > 1)
				elapsedTimeString += string.Format("{0} seconds", (elapsedTime.TotalSeconds - (elapsedTime.Minutes * 60)).ToString("0.#"));
			// Make sure we display the time properly, even for super fast operations that took a fraction of a second to complete.
			else
				elapsedTimeString += string.Format("{0} seconds", (elapsedTime.TotalSeconds - (elapsedTime.Minutes * 60)).ToString("0.###"));

			Console.WriteLine("Elapsed time: " + elapsedTimeString);
		}
	}
}
